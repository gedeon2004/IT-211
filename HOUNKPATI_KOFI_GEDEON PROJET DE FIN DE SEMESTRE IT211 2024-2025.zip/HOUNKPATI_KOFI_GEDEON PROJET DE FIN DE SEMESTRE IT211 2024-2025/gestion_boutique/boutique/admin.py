from django.contrib import admin
from .models import Categorie, Produit, Vente, ArticleVendu

admin.site.register(Categorie)
admin.site.register(Produit)
admin.site.register(Vente)
admin.site.register(ArticleVendu)

# Register your models here.
